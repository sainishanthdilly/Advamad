<?php
/**
 * Created by PhpStorm.
 * User: sainishanthdilly
 * Date: 8/27/17
 * Time: 3:23 PM
 */


$servername = "localhost";
$username = "root";
$password = "root";

// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE aminclass1";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}


$conn->select_db("aminclass1");

$sql = "CREATE TABLE User (
    Email VARCHAR(50),
  FirstName VARCHAR(50),
  LastName VARCHAR(50),
  Password_User VARCHAR(50),
  
  PRIMARY KEY(Email) 
)";
if ($conn->query($sql) === TRUE) {
    echo "Table created successfully";
} else {
    echo "Error creating Table: " . $conn->error;
}


$sql =
   "insert into User values('abc@abc.com','sdsadd','asdasas','password')";
if ($conn->query($sql) === TRUE) {
    echo "Table created successfully";
} else {
    echo "Error creating Table: " . $conn->error;
}






$conn->close();


?>