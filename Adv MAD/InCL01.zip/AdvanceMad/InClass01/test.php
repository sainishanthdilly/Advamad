<html>
<?php
   echo "print";
?>

</html>

